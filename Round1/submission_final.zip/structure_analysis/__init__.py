from .model import StructureModel
