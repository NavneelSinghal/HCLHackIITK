from utility import *

for h,p,l in get('.', strings(benigns())):
    print(f'Hash = {h}')
    print(f'Path = {p}')
    print(f'Label detect = {l}')
    print('---')
